iSlicer Bridge macOS build

1. Unzip this file.
2. Open Terminal in this folder.
3. Run:

   chmod +x ./iSlicerBridge
   ./iSlicerBridge

The bridge listens on http://localhost:8005.
For anywhere access, install Tailscale on this Mac and your iPhone, then use:

   http://100.x.x.x:8005

This command-line build is for early testing. The full menu-bar app should be
signed and notarized before public distribution.
